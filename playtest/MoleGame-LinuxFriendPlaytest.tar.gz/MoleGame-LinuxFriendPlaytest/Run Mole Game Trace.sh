#!/usr/bin/env bash
set -euo pipefail
cd -- "$(dirname -- "${BASH_SOURCE[0]}")"
export MOLE_ASSET_ROOT="${PWD}"
exec ./mole_runtime --friend-connect --play --input-trace --netplay-delay 2 "$@"
