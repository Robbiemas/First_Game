# Mole Game Linux / Steam Deck Friend Playtest

This folder is a Linux playtest package for the native Rust SDL3/WUP runtime.
It is built for x86_64 Linux with bundled SDL3 and desktop SDL video backends,
so it is intended to run on Steam Deck under SteamOS Desktop Mode or as an
added non-Steam game.

## Requirements

- A desktop session that can open SDL windows.
- Optional WUP-028/GameCube adapter access through normal Linux USB permissions.

## Launchers

- `./Run Mole Game.sh`: Friend Connect playtest with UCF enabled.
- `./Run Mole Game Trace.sh`: Friend Connect with controller/core input trace JSONL enabled.
- `./Run Mole Game Vanilla No UCF.sh`: Friend Connect with UCF disabled.
- `./Run Local Practice.sh`: local single-machine SDL practice.
- `./Run Local Practice Vanilla No UCF.sh`: local practice with UCF disabled.
- `./Check WUP Adapter.sh`: checks whether the native adapter path can see the adapter.

Friend Connect uses Supabase only for endpoint setup. Gameplay packets are direct
UDP between peers and use the same two-frame delay/repair buffer as the Windows
playtest package. This Linux package can connect to the Windows Friend Connect
playtest when both clients can reach each other over UDP.
